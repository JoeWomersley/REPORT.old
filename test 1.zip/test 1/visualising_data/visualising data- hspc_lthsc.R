BiocManager::install("biomaRt")
fs::dir_create("figures")
library(tidyverse)
library(conflicted)
conflict_prefer("filter", "dplyr")



# importing data ----------------------------------------------------------
# We need to import both the normalised counts and the statistical results. 
# We will need all of these for the visualisation and interpretation.
# 
# 🎬 Import the normalised counts for the lthsc and HSPC cell types. I used 
# the names lthsc and hspc for the dataframes.
# 
# 🎬 Combine the two dataframes (minus one set of gene ids) into one 
# dataframe called prog_hspc:

lthsc <- read_csv("data/surfaceome_lthsc.csv")
hspc <- read_csv("data/surfaceome_hspc.csv")
lthsc_hspc_results <- read_csv("results/lthsc_hspc_results.csv")
lthsc_hspc <- bind_cols(lthsc, hspc[-1])
lthsc_hspc_results <- lthsc_hspc_results |> 
  left_join(lthsc_hspc, by = "ensembl_gene_id")


# Add gene information from Ensembl using biomaRt -------------------------

library(biomaRt)
# Connect to the mouse database
ensembl <- useMart(biomart = "ensembl", 
                   dataset = "mmusculus_gene_ensembl")

# See what information we can retrieve
listAttributes(mart = ensembl) |> head(20)

# name                                description         page
# 1                ensembl_gene_id                             Gene stable ID feature_page
# 2        ensembl_gene_id_version                     Gene stable ID version feature_page
# 3          ensembl_transcript_id                       Transcript stable ID feature_page
# 4  ensembl_transcript_id_version               Transcript stable ID version feature_page
# 5             ensembl_peptide_id                          Protein stable ID feature_page
# 6     ensembl_peptide_id_version                  Protein stable ID version feature_page
# 7                ensembl_exon_id                             Exon stable ID feature_page
# 8                    description                           Gene description feature_page
# 9                chromosome_name                   Chromosome/scaffold name feature_page
# 10                start_position                            Gene start (bp) feature_page
# 11                  end_position                              Gene end (bp) feature_page
# 12                        strand                                     Strand feature_page
# 13                          band                             Karyotype band feature_page
# 14              transcript_start                      Transcript start (bp) feature_page
# 15                transcript_end                        Transcript end (bp) feature_page
# 16      transcription_start_site             Transcription start site (TSS) feature_page
# 17             transcript_length Transcript length (including UTRs and CDS) feature_page
# 18                transcript_tsl             Transcript support level (TSL) feature_page
# 19      transcript_gencode_basic                   GENCODE basic annotation feature_page
# 20             transcript_appris                          APPRIS annotation feature_page

# There are many (2,985!) possible bits of information (attributes) that can be 
# obtained. You can replace head(20) with View() to see them all.
# 
# We use the getBM() function to retrieve information from the database. 
# The filters argument is used to specified what kind of identifier we are 
# supplying to retrieve information. The attributes argument is used to select 
# the information we want to retrieve. The values argument is used to specify
# the identifiers. The mart argument is used to specify the connection we created.

# get the gene information:

gene_info <- getBM(filters = "ensembl_gene_id",
                   attributes = c("ensembl_gene_id",
                                  "external_gene_name",
                                  "description"),
                   values = lthsc_hspc_results$ensembl_gene_id,
                   mart = ensembl)
# 
#   We are getting the gene name and and a description. We also need to get the
#   id because we will use that to merge the gene_info dataframe with the 
#   prog_hspc_results dataframe. Notice the dataframe returned only has 279 rows 
#   - one of the ids does not have information.

# 🎬 We can find which is missing with:

lthsc_hspc_results |> select(ensembl_gene_id) |> 
  filter(!ensembl_gene_id %in% gene_info$ensembl_gene_id)

# Oh, conflicted has flagged a conflict for us.    
# ❓ What is the id which is missing information?
# We might want to look that up - but let’s worry about it later if it turns 
# out to be something important.

# 🎬 Merge the gene information with the results:

lthsc_hspc_results <- lthsc_hspc_results |> left_join(gene_info, by = "ensembl_gene_id")    

# I recommend viewing the dataframe to see the new columns. We now have dataframe 
# with all the info we need, normalised counts, log2 normalised counts, 
# statistical comparisons with fold changes and p values, information about the 
# gene other than just the id





# Write the significant genes to file -------------------------------------

# We will create dateframe of the signifcant genes and write them to file. 
# These are the files you want to examine in more detail along with the 
# visualisations to select your genes of interest.
# 
# 🎬 Create a dataframe of the genes significant at the 0.01 level:

lthsc_hspc_results_sig0.01 <- lthsc_hspc_results |> 
  filter(FDR <= 0.01)

# Write the dataframe to file
# 
# 🎬 Create a dataframe of the genes significant at the 0.05 level and
#    write to file:
#   
# ❓How many genes are significant at the 0.01 and 0.05 levels?
# ALOT DIFFERENT!!



# View the relationship between cells using PCA ---------------------------

# We have 280 genes in our dataset. PCA will allow us to plot our cells in the
# “gene expression” space so we can see if lthsc cells cluster together and HSPC 
# cells cluster together as we would expect. We do this on the log2 transformed 
# normalised counts.
# 
# Our data have genes in rows and samples in columns which is a common organisation 
# for gene expression data. However, PCA expects cells in rows and genes, 
# the variables, in columns. We can transpose the data to get it in the correct 
# format.
# 
# 🎬 Transpose the log2 transformed normalised counts:


lthsc_hspc_trans <- lthsc_hspc_results_sig0.01 |> 
  dplyr::select(starts_with(c("HSPC_", "LT.HSC_"))) |>
  t() |> 
  data.frame()

# We have used the select() function to select all the columns that start with 
# Prog_ or HSPC_. We then use the t() function to transpose the dataframe. 
# We then convert the resulting matrix to a dataframe using data.frame(). 
# If you view that dataframe you’ll see it has default column name which we can 
# fix using colnames() to set the column names to the gene ids.
# 
# 🎬 Set the column names to the gene ids:

colnames(lthsc_hspc_trans) <- lthsc_hspc_results_sig0.01$ensembl_gene_id

# perform PCA using standard functions

pca <- lthsc_hspc_trans |> prcomp(rank. = 15) 
summary(pca)

# The Proportion of Variance tells us how much of the variance is explained by 
# each component. We can see that the first component explains 0.1099 of the 
# variance, the second 0.04874, and the third 0.2498. Together the first three 
# components explain 18% of the total variance in the data. Plotting PC1 against 
# PC2 will capture about 16% of the variance. This is not that high but it likely 
# better than we would get plotting any two genes against each other. To plot the
# PC1 against PC2 we will need to extract the PC1 and PC2 score from the pca 
# object and add labels for the cells.
# 
# 🎬 Create a dataframe of the PC1 and PC2 scores which are in pca$x and 
# add the cell ids:

pca_labelled <- data.frame(pca$x,
                           cell_id = row.names(lthsc_hspc_trans))

# It will be helpful to add a column for the cell type so we can label points. 
# One way to do this is to extract the information in the cell_id column into 
# two columns.
# 
# 🎬 Extract the cell type and cell number from the cell_id column 
# (keeping the cell_id column):

pca_labelled <- pca_labelled |> 
  extract(cell_id, 
          remove = FALSE,
          c("cell_type", "cell_number"),
          "([. a-zA-Z]{4,6})_([0-9]{3})")
# 
# "([a-zA-Z]{4})_([0-9]{3})" is a regular expression - or regex. [a-zA-Z] means 
# any lower or upper case letter, {4} means 4 of them, and [0-9] means any number, 
# {3} means 3 of them. The brackets around the two parts of the regex mean we 
# want to extract those parts. The first part goes into cell_type and the second 
# part goes into cell_number. The _ between the two patterns matches the 
# underscore and the fact it isn’t in a bracket means we don’t want to keep it.
# 
# We can now plot the PC1 and PC2 scores.

# 🎬 Plot PC1 against PC2 and colour the points by cell type:

pca <- pca_labelled |> 
  ggplot(aes(x = PC1, y = PC2, 
             colour = cell_type)) +
  geom_point(alpha = 0.4) +
  scale_colour_viridis_d(end = 0.8, begin = 0.15,
                         name = "Cell type") +
  theme_classic()
pca

ggsave("figures/lthsc_hspc-pca.png",
       plot = pca,
       height = 3, 
       width = 4,
       units = "in",
       device = "png")




# Visualise the expression of the most significant genes using a heatmap --------

# A heatmap is a common way to visualise gene expression data. Often people will 
# create heatmaps with thousands of genes but it can be more informative to use a 
# subset along with clustering methods. We will use the genes which are 
# significant at the 0.01 level.
# 
# We are going to create an interactive heatmap with the heatmaply 
# (Galili et al. 2017) package. heatmaply takes a matrix as input so we need to 
# convert a dataframe of the log2 values to a matrix. We will also set the 
# rownames to the gene names.
# 
# 🎬 Convert a dataframe of the log2 values to a matrix. I have used sample() 
# to select 70 random columns so the heatmap is generated quickly:


mat <- lthsc_hspc_results_sig0.01 |> 
  dplyr::select(starts_with(c("lthsc", "HSPC"))) |>
  dplyr::select(sample(1:701, size = 70)) |>
  as.matrix()

# 🎬 Set the row names to the gene names:

rownames(mat) <- lthsc_hspc_results_sig0.01$ensembl_gene_id

# You might want to view the matrix by clicking on it in the environment pane.
# 
# 🎬 Load the heatmaply package:

library(heatmaply)

# We need to tell the clustering algorithm how many clusters to create. 
# We will set the number of clusters for the cell types to be 2 and the 
# number of clusters for the genes to be the same since it makes sense to
# see what clusters of genes correlate with the cell types.

n_cell_clusters <- 2
n_gene_clusters <- 2
# 
# 🎬 Create the heatmap:

heatmaply(mat, 
          scale = "row",
          k_col = n_cell_clusters,
          k_row = n_gene_clusters,
          fontsize_row = 7, fontsize_col = 10,
          labCol = colnames(mat),
          labRow = rownames(mat),
          heatmap_layers = theme(axis.line = element_blank()))

# It will take a minute to run and display. On the vertical axis are genes 
# which are differentially expressed at the 0.01 level. On the horizontal 
# axis are cells. We can see that cells of the same type don’t cluster that 
# well together. We can also see two clusters of genes but the pattern of 
# gene is not as clear as it was for the frogs and the correspondence with 
# the cell clusters is not as strong.
# 
# The heatmap will open in the viewer pane (rather than the plot pane) because 
# it is html. You can “Show in a new window” to see it in a larger format. 
# You can also zoom in and out and pan around the heatmap and download it as 
# a png. You might feel the colour bars is not adding much to the plot. 
# You can remove it by setting hide_colorbar = TRUE, in the heatmaply() function.
# 
# Using all the cells is worth doing but it will take a while to generate 
# the heatmap and then show in the viewer so do it sometime when you’re 
# ready for a coffee break.


# Visualise all the results with a volcano plot ---------------------------

library(ggrepel)

lthsc_hspc_results <- lthsc_hspc_results |> 
  mutate(log10_FDR = -log10(FDR),
         sig = FDR < 0.05,
         bigfc = abs(summary.logFC) >= 2)   
vol <- lthsc_hspc_results |> 
  ggplot(aes(x = summary.logFC, 
             y = log10_FDR, 
             colour = interaction(sig, bigfc))) +
  geom_point(size = 5) +
  geom_hline(yintercept = -log10(0.05), 
             linetype = "dashed") +
  geom_vline(xintercept = 1, 
             linetype = "dashed") +
  geom_vline(xintercept = -1, 
             linetype = "dashed") +
  scale_x_continuous(expand = c(0, 0)) +
  scale_y_continuous(expand = c(0, 0)) +
  scale_colour_manual(values = c("gray",
                                 "pink",
                                 "deeppink")) +
  geom_text_repel(data = subset(lthsc_hspc_results, 
                                bigfc & sig),
                  aes(label = external_gene_name),
                  size = 5,
                  max.overlaps = 50, vjust = 1.75) +
  theme_classic() +
  theme(legend.position = "none", 
        axis.title = element_text(size = 30), axis.text = element_text(size = 30),# Adjust the font size for both x and y axis labels
        plot.title = element_text(size = 40, hjust = 0.5),  # Adjust the title font size and center it
        plot.margin = margin(t = 30)) +  # Add margin at the top for the title
  
  ggtitle("HSPC vs LT.HSC")

vol

ggsave("figures/lthsc-hspc-volcano.png",
       plot = vol,
       height = 4.5, 
       width = 4.5,
       units = "in",
       device = "png")





# pathway analysis  -------------------------------------------------------------

# Install and load the clusterProfiler package
if (!requireNamespace("BiocManager", quietly = TRUE)) {
  install.packages("BiocManager")
}
BiocManager::install("clusterProfiler")
library(clusterProfiler)

# Install and load the appropriate gene ID conversion package
if (!requireNamespace("BiocManager", quietly = TRUE)) {
  install.packages("BiocManager")
}
BiocManager::install("org.Mm.eg.db") # For mouse data
library(org.Mm.eg.db)
geneList <- lthsc_hspc_results$ensembl_gene_id
geneList <- mapIds(org.Mm.eg.db, keys = geneList, column = "ENTREZID", keytype = "ENSEMBL")
# Perform pathway analysis (KEGG pathways)
result <- enrichKEGG(gene = geneList, organism = "mmu", pvalueCutoff = 0.05)
dotplot(result)


# pathway analysis for differentially expressed genes ---------------------


# Filter genes based on summary.logFC threshold (-2 to +2)
filtered_genes <- lthsc_hspc_results$ensembl_gene_id[lthsc_hspc_results$summary.logFC <= -1 | lthsc_hspc_results$summary.logFC >= 1]

# Check if there are any genes left after filtering
if (length(filtered_genes) == 0) {
  stop("No genes meet the specified logFC threshold.")
}

# Perform gene ID conversion
filtered_genes_entrez <- mapIds(org.Mm.eg.db, keys = filtered_genes, column = "ENTREZID", keytype = "ENSEMBL")

# Check if there are any genes left after ID conversion
if (length(filtered_genes_entrez) == 0) {
  stop("No genes were mapped to ENTREZID.")
}

# Perform pathway analysis (KEGG pathways) on filtered genes
result <- enrichKEGG(gene = filtered_genes_entrez, organism = "mmu", pvalueCutoff = 0.05)

# Check if there are any significant pathways
if (nrow(result) == 0) {
  stop("No significant pathways found.")
}

# Plot the results
dotplot(result)





# highlighting volcano plot for Mmrn1 -------------------------------------

library(ggrepel)

lthsc_hspc_results <- lthsc_hspc_results |> 
  mutate(log10_FDR = -log10(FDR),
         sig = FDR < 0.05,
         bigfc = abs(summary.logFC) >= 2)   


mmrn1 <- lthsc_hspc_results |> 
  filter(ensembl_gene_id == "ENSMUSG00000054641") 

# Create a data frame for the highlight region
highlight_region <- data.frame(
  xmin = -1.5,
  xmax = 1.5,
  ymin = -Inf,
  ymax = -log10(0.05)
)

vol2 <- ggplot(data = lthsc_hspc_results, aes(x = summary.logFC, 
                                              y = log10_FDR, 
                                              colour = interaction(sig, bigfc), 
                                              size = ifelse(bigfc & sig, "red", "other"))) +
  geom_point() +
  geom_hline(yintercept = -log10(0.05), 
             linetype = "dashed") +
  geom_vline(xintercept = 1, 
             linetype = "dashed") +
  geom_vline(xintercept = -1, 
             linetype = "dashed") +
  geom_rect(data = highlight_region, aes(xmin = 1, xmax = 3, ymin = 0, ymax = 35), fill = "green", alpha = 0.15, inherit.aes = FALSE) +
  geom_rect(data = highlight_region, aes(xmin = -4, xmax = -1, ymin = 0, ymax = 35), fill = "red", alpha = 0.15, inherit.aes = FALSE) +
  scale_x_continuous(expand = c(0, 0)) + 
  scale_y_continuous(expand = c(0, 0)) +
  scale_colour_manual(values = c("gray",
                                 "#333333",
                                 "red")) +
  scale_size_manual(name = "Size",
                    values = c("red" = 3.5, "other" = 2),  # Adjust size values for red and other points
                    breaks = c("red", "other")) +
  guides(size = guide_legend(title = "Size")) +  # Add a legend title for size
  geom_point(data = mmrn1, colour = "blue", size = 4) +
  geom_text_repel(data = subset(lthsc_hspc_results, bigfc & sig), aes(x = summary.logFC, y = log10_FDR, label = external_gene_name), size = 3.2, max.overlaps = 20, vjust = 0.7, hjust = 1.1, colour = "black") +
  theme_classic() +
  theme(legend.position = "none", 
        axis.title = element_text(size = 10), axis.text = element_text(size = 10),
        plot.title = element_text(size = 15, hjust = 0.5),
        plot.margin = margin(t = 10))

vol2


# MA plots Mmrn1 highlighted----------------------------------------------------------------

library(ggplot2)
library(ggrepel)  # For geom_text_repel

# Assuming prog_hspc_results contains necessary columns like summary.log.fc, p-values, FDR, ensemble gene ids

# Calculate average expression (A) for HSPCs
lthsc_hspc_results$avg_lthsc_expression <- rowMeans(lthsc_hspc_results[, grepl("^LT.HSC_", colnames(lthsc_hspc_results))])

# Define color gradient
color_gradient <- scale_color_gradient(low = "gray", high = "deeppink")

# Create a data frame for the highlight region
highlight_region <- data.frame(
  xmin = -1.5,
  xmax = 1.5,
  ymin = -Inf,
  ymax = -log10(0.05)
)

# Filter data for a specific gene (e.g., Mmrn1)
Mmrn1 <- lthsc_hspc_results |> 
  filter(ensembl_gene_id == "ENSMUSG00000054641") 

# Create the MA plot with color gradient
ma_plot_lthsc <- ggplot(lthsc_hspc_results, aes(x = avg_lthsc_expression, y = summary.logFC, color = avg_lthsc_expression)) +
  geom_point(size = 2) +
  geom_point(data = Mmrn1, colour = "blue", size = 3) +  # this adds a blue point
  color_gradient +
  geom_rect(data = highlight_region, aes(xmin = 0, xmax = 10.5, ymin = -4, ymax = 0), fill = "red", alpha = 0.15, inherit.aes = FALSE) +
  geom_rect(data = highlight_region, aes(xmin = 0, xmax = 10.5, ymin = 0, ymax = 3), fill = "green", alpha = 0.15, inherit.aes = FALSE) +
  geom_hline(yintercept = log2(1), linetype = "solid") +
  geom_text_repel(data = subset(lthsc_hspc_results, ensembl_gene_id == "ENSMUSG00000054641"), aes(label = "Mmrn1"), color = "blue", size = 5.1, box.padding = 0.5, segment.size = 0.5, vjust = 1) +
  labs(x = "Average Expression (A) in LT.HSC", y = "Log2 Fold Change (M)", title = "MA Plot: LT.HSC vs HSPC Cells") +
  theme_minimal() + theme(
    plot.title = element_text(hjust = 0.5, vjust = 0.5, size = 15),
    axis.text = element_text(size = 10),
    axis.title = element_text(size = 15),
    legend.position = "none"
  )

ma_plot_lthsc

ggsave("visualising_data/MA plots/Progs_vs_HSPC.jpeg", plot = vol2)



# MA plots ----------------------------------------------------------------

library(ggplot2)
library(ggrepel)  # For geom_text_repel

# Assuming prog_hspc_results contains necessary columns like summary.log.fc, p-values, FDR, ensemble gene ids

# Calculate average expression (A) for HSPCs
lthsc_hspc_results$avg_lthsc_expression <- rowMeans(lthsc_hspc_results[, grepl("^LT.HSC_", colnames(lthsc_hspc_results))])

# Define color gradient
color_gradient <- scale_color_gradient(low = "gray", high = "deeppink")

# Filter data for a specific gene (e.g., Mmrn1)
Mmrn1 <- lthsc_hspc_results |> 
  filter(ensembl_gene_id == "ENSMUSG00000054641") 

# Create the MA plot with color gradient
ma_plot_lthsc <- ggplot(lthsc_hspc_results, aes(x = avg_lthsc_expression, y = summary.logFC, color = avg_lthsc_expression)) +
  geom_point(size = 5) +
  color_gradient +
  geom_hline(yintercept = log2(1), linetype = "solid") +
  labs(x = "Average Expression (A) in LT.HSC", y = "Log2 Fold Change (M)", title = "MA Plot: HSPC vs LT.HSC cells") +
  theme_minimal() + theme(
    plot.title = element_text(hjust = 0.5, vjust = 0.5, size = 30),
    axis.text = element_text(size = 20),
    axis.title = element_text(size = 25),
    legend.position = "none"
  )

ma_plot_lthsc




















